package br.com.meuprojeto.portal_estagios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortalEstagiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortalEstagiosApplication.class, args);
	}

}
