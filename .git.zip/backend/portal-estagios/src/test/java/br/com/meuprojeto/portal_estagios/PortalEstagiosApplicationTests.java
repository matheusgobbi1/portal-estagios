package br.com.meuprojeto.portal_estagios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalEstagiosApplicationTests {

	@Test
	void contextLoads() {
	}

}
